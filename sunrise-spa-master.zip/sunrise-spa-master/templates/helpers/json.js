module.exports = function (context) {
    return JSON.stringify(context);
};
