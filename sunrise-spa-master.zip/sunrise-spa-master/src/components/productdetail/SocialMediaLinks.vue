<template>
  <div class="row">
    <div class="col-sm-12">
      <div class="social-share">
        <ul class="social-icons pdp-social-icons">
          <a href="">
            <li>
              <img class="social-icon"
                   src="../../assets/img/Facebook.png"
                   alt="facebook">
            </li>
          </a>
          <a href="">
            <li>
              <img class="social-icon"
                   src="../../assets/img/Pinterest.png"
                   alt="pinterest">
            </li>
          </a>
          <a href="">
            <li>
              <img class="social-icon"
                   src="../../assets/img/Google.png"
                   alt="google plus">
            </li>
          </a>
        </ul>
        <ul class="social-icons">
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
};
</script>
