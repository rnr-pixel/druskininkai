<template>
  <BaseFooter/>
</template>

<script>
import BaseFooter from './BaseFooter.vue';

export default {
  components: {
    BaseFooter,
  },
};
</script>
