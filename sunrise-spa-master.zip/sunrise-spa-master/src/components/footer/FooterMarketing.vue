<template>
  <div class="col-sm-6 text-center newsletter-box">
    <NewsletterSubscriptionForm/>
    <div class="row">
      <div class="col-sm-8 text-left card-info footer-title">
        <p>{{ $t("paySecure") }}</p>
        <img src="../../assets/img/cards.png" alt="payment types"
             class="img-responsive payment-cards"/>
      </div>
      <div class="col-sm-4 text-left card-info footer-title">
        <p>{{ $t("followUs") }}</p>
        <ul class="social-icons">
          <li><a href="#">
            <img class="social-icon" src="../../assets/img/Facebook.png" alt="Facebook">
          </a></li>
          <li><a href="#">
            <img class="social-icon" src="../../assets/img/Pinterest.png" alt="Pinterest">
          </a></li>
          <li><a href="#">
            <img class="social-icon" src="../../assets/img/Google.png" alt="Google+">
          </a></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import NewsletterSubscriptionForm from './NewsletterSubscriptionForm.vue';

export default {
  components: { NewsletterSubscriptionForm },
};
</script>

<i18n>
en:
  paySecure: "Pay securely with these payment methods"
  followUs: "Follow us"
de:
  paySecure: "Sicher zahlen"
  followUs: "Follow us"
</i18n>
