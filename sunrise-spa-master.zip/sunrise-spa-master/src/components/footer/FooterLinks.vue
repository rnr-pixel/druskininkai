<template>
  <div>
    <div class="col-sm-2">
      <div class="footer-col">
        <ul>
          <li class="footer-title hidden-xs">{{ $t("customerCare") }}</li>
          <li><a href="#">{{ $t("contactUs") }}</a></li>
          <li><a href="#">{{ $t("help") }}</a></li>
          <li><a href="#">{{ $t("shipping") }}</a></li>
          <li><a href="#">{{ $t("returns") }}</a></li>
          <li><a href="#">{{ $t("sizeGuide") }}</a></li>
        </ul>
      </div>
    </div>
    <div class="col-sm-2 hidden-xs">
      <div class="footer-col">
        <ul>
          <li class="footer-title hidden-xs">{{ $t("aboutUs") }}</li>
          <li><a href="#">{{ $t("ourStory") }}</a></li>
          <li><a href="#">{{ $t("careers") }}</a></li>
        </ul>
      </div>
    </div>
    <div class="col-sm-2 hidden-xs">
      <div class="footer-col">
        <ul>
          <li class="footer-title hidden-xs">{{ $t("shortcuts") }}</li>
          <li><a href="#">{{ $t("myAccount") }}</a></li>
          <li><a href="#">{{ $t("storeLocator") }}</a></li>
          <li><a href="#">{{ $t("giftCards") }}</a></li>
          <li><a href="#">{{ $t("payment") }}</a></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<i18n>
en:
  customerCare: "Customer Care"
  contactUs: "Contact Us"
  help: "Help"
  shipping: "Shipping"
  returns: "Returns"
  sizeGuide: "Size Guide"
  aboutUs: "About Us"
  ourStory: "Our Story"
  careers: "Careers"
  shortcuts: "Shortcuts"
  myAccount: "My Account"
  storeLocator: "Store Locator"
  giftCards: "Gift Cards"
  payment: "Payment"
de:
  customerCare: "Kundenservice"
  contactUs: "Kontaktieren Sie uns"
  help: "Hilfe"
  shipping: "Versand"
  returns: "Retoure"
  sizeGuide: "Größentabelle"
  aboutUs: "Über uns"
  ourStory: "Unsere Geschichte"
  careers: "Karriere"
  shortcuts: "Shortcuts"
  myAccount: "Mein Konto"
  storeLocator: "Filiale suchen"
  giftCards: "Geschenkkarten"
  payment: "Zahlung"
</i18n>
